# Địa Bạ Chrome Extension (Google Maps Profiler)

Chrome Extension (Manifest V3) chuyên dụng cho đội ngũ Sale và chuyên viên tư vấn GoDine nhằm thu thập các dữ liệu bổ sung bị Google Maps ẩn khi chưa đăng nhập (Menu chữ, Tab Giới thiệu / Tiện ích, Giờ đặc biệt).

## Kiến trúc lai (Hybrid Extraction)
1. **Script cố định (Ưu tiên số 1)**: Thao tác DOM chuẩn qua `aria-label`, `role`, và văn bản hiển thị (hỗ trợ cả tiếng Việt và tiếng Anh). Không dựa vào class CSS bị mã hóa ngẫu nhiên.
2. **AI Fallback (Tự động kích hoạt khi script gãy)**: Nếu script không tìm thấy tab hoặc bóc tách ra 0 mục, extension sẽ chụp tóm tắt text của khung bên trái và danh sách nút bấm, gửi lên AI Gateway (`POST /v1/llm/chat`). AI trả về hành động: `{ "action": "click", "index": N }`, `{ "action": "extract", "data": {...} }`, hoặc `{ "action": "give_up" }` (tối đa 6 bước mỗi phần).

---

## Hướng dẫn cài đặt & Cấu hình

### 1. Cài đặt vào Google Chrome
1. Mở trình duyệt Google Chrome, truy cập `chrome://extensions/`.
2. Bật công tắc **"Developer mode"** (Chế độ dành cho nhà phát triển) ở góc trên bên phải.
3. Bấm nút **"Load unpacked"** (Tải tiện ích đã giải nén).
4. Chọn thư mục `extension/` trong repo này.
5. Sau khi cài thành công, Chrome sẽ hiển thị extension **"Địa Bạ - Google Maps Profiler"** kèm một Extension ID (ví dụ: `abcdefghijklmnop...`).

### 2. Cấu hình AI Gateway
1. Nhấp chuột phải vào biểu tượng Extension Địa Bạ trên thanh công cụ Chrome, chọn **"Options"** (hoặc mở `chrome-extension://<EXTENSION_ID>/options.html`).
2. Nhập thông tin:
   - **Địa chỉ AI Gateway**: mặc định `http://localhost:8000` (hoặc URL production).
   - **Gateway API Key**: nhập mã khóa API tương ứng với service trên Gateway (được cấu hình trong `GATEWAY_API_KEYS`).
3. Bấm **"Lưu cấu hình"**.

### 3. Cấu hình Web Địa Bạ nhận Extension
1. Sao chép **Extension ID** từ `chrome://extensions/`.
2. Thêm vào môi trường web:
   ```env
   NEXT_PUBLIC_DIABA_EXTENSION_ID=<ID_VỪA_SAO_CHÉP>
   ```

---

## Cách kiểm tra và sử dụng

### Cách 1: Test tay qua Extension Popup
1. Mở tab Google Chrome và đăng nhập tài khoản Google.
2. Mở một nhà hàng bất kỳ trên Google Maps (ví dụ: một nhà hàng có thực đơn đầy đủ).
3. Bấm vào icon Extension Địa Bạ trên thanh công cụ trình duyệt.
4. Chọn các mục muốn thu thập: Menu chữ, Tiện ích, Giờ đặc biệt.
5. Bấm nút **"Thu thập trang Maps hiện tại"**.
6. Kết quả JSON trả về sẽ hiển thị ngay trong khung popup.

### Cách 2: Thu thập tự động từ Web Địa Bạ
1. Mở trang Web Địa Bạ (`http://localhost:3000`).
2. Tìm kiếm và chọn một quán ăn.
3. Khi hồ sơ hiển thị và hệ thống phát hiện Extension đã được cài đặt, giao diện sẽ xuất hiện nút **"Thu thập phần còn thiếu từ Google Maps"**.
4. Bấm nút, Extension sẽ ngầm mở tab Maps tới quán, thu thập dữ liệu còn thiếu, đóng tab và tự động cập nhật vào hồ sơ trên màn hình.

---

## Giới hạn & Lưu ý
- **Yêu cầu đăng nhập**: Trình duyệt Chrome phải được đăng nhập tài khoản Google để Google Maps mở đầy đủ tab Menu và tab Giới thiệu.
- **Thực đơn dạng ảnh**: Một số nhà hàng chỉ đăng ảnh chụp menu mà không nhập text menu vào hệ thống Google Business -> Extension sẽ ghi nhận `menuPhotosOnly: true` thay vì tạo thực đơn giả.
- **Tốc độ mạng**: Google Maps là Single Page Application nặng, khi mở tab ngầm cần đợi vài giây để DOM hydrate hoàn chỉnh trước khi bóc tách.
